import os

from data_loading import load_data_generators
from model_creation import build_model
from model_training import hyperparameter_search, save_model, train_model


def test_train_model():
    # Test the train_model function
    # Create a simple model
    model = build_model()

    # Load small data generators
    (
        (train_generator, train_length),
        (test_generator, test_length),
        (val_generator, val_length),
    ) = load_data_generators("data/tests_dataset")

    # Train the model
    model, history = train_model(
        model,
        train_generator,
        train_length,
        val_generator,
        val_length,
        epochs=1,
    )
    # Check that the model is not None
    assert model is not None
    # Check that the history is not None
    assert history is not None
    # Check that the history has the correct keys
    assert "loss" in history.history
    assert "val_loss" in history.history


# Test the hyperparameter_search function
def test_hyperparameter_search():
    #     # Load small data generators
    (
        (train_generator, train_length),
        (test_generator, test_length),
        (val_generator, val_length),
    ) = load_data_generators("data/tests_dataset")

    best_model, best_history, best_hyperparameters = hyperparameter_search(
        train_generator, train_length, val_generator, val_length, epochs=1
    )

    # Assertions
    assert best_model is not None
    assert best_history is not None
    assert best_hyperparameters is not None

    # Check if the hyperparameters of the best model match one of the sets
    assert best_hyperparameters in [
        {
            "learning_rate": 1e-3,
            "batch_size": 32,
            "dropout_rate": [0.1, 0.1, 0.2, 0.2, 0.3],
            "num_filters": [16, 32, 64, 128, 256],
            "epochs": 100,
        },
        {
            "learning_rate": 1e-4,
            "batch_size": 64,
            "dropout_rate": [0.1, 0.1, 0.2, 0.2, 0.3],
            "num_filters": [32, 64, 128, 256, 512],
            "epochs": 120,
        },
        {
            "learning_rate": 5e-4,
            "batch_size": 16,
            "dropout_rate": [0.1, 0.2, 0.2, 0.2, 0.3],
            "num_filters": [16, 32, 64, 128, 256],
            "epochs": 150,
        },
        {
            "learning_rate": 2e-4,
            "batch_size": 32,
            "dropout_rate": [0.2, 0.2, 0.3, 0.3, 0.4],
            "num_filters": [16, 32, 64, 128, 256],
            "epochs": 100,
        },
    ]


# Test save_model function
def test_save_model():
    # Create a simple model
    model = build_model()

    # Save the model
    save_model(model, "tests/model.h5")

    # Check if the model file exists
    assert os.path.exists("tests/model.h5")

    # Remove the model file
    os.remove("tests/model.h5")
