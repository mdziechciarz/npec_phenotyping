import cv2

from landmarks_detection import detect_landmarks


def test_measure_root_lengths():
    mask = cv2.imread("data/test_mask.png", cv2.IMREAD_GRAYSCALE)

    result = detect_landmarks(mask)

    # Assert the result matches the expected output
    assert isinstance(result, list)
    assert isinstance(result[0], dict)
    assert "primary_root_start" in result[0]
    assert "primary_root_end" in result[0]
    assert "l_root_tips" in result[0]
    assert isinstance(result[0]["primary_root_start"], tuple)
    assert isinstance(result[0]["primary_root_end"], tuple)
    assert isinstance(result[0]["l_root_tips"], list)
    if len(result[0]["l_root_tips"]) > 0:
        assert isinstance(result[0]["l_root_tips"][0], tuple)

    assert isinstance(result[0]["primary_root_start"][0], int) and isinstance(
        result[0]["primary_root_start"][1], int
    )
    assert isinstance(result[0]["primary_root_end"][0], int) and isinstance(
        result[0]["primary_root_end"][1], int
    )
