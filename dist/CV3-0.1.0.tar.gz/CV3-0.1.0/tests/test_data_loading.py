import os
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import pytest
from unittest.mock import MagicMock, patch
from src2.data_loading import load_data_generators, validate_dataset


@pytest.fixture
def mock_flow_from_directory():
    with patch(
        "tensorflow.keras.preprocessing.image.ImageDataGenerator.flow_from_directory",
        return_value=MagicMock(),
    ) as mock:
        yield mock


def test_load_data_generators(mock_flow_from_directory):
    patched_dataset_path = "mock_path"
    data_type = "root"

    # Call the function
    (
        (train_generator, train_length),
        (test_generator, test_length),
        (val_generator, val_length),
    ) = load_data_generators(patched_dataset_path, data_type)

    # Check that flow_from_directory is called correctly for training images
    mock_flow_from_directory.assert_any_call(
        f"{patched_dataset_path}/dataset_patched/images/train",
        target_size=(256, 256),
        batch_size=16,
        class_mode=None,
        color_mode="grayscale",
        seed=42,
    )

    # Check that flow_from_directory is called correctly for training masks
    mock_flow_from_directory.assert_any_call(
        f"{patched_dataset_path}/dataset_patched/masks/{data_type}/train",
        target_size=(256, 256),
        batch_size=16,
        class_mode=None,
        color_mode="grayscale",
        seed=42,
    )

    # Check that flow_from_directory is called correctly for test images
    mock_flow_from_directory.assert_any_call(
        f"{patched_dataset_path}/dataset_patched/images/test",
        target_size=(256, 256),
        batch_size=16,
        class_mode=None,
        color_mode="grayscale",
        seed=42,
    )

    # Check that flow_from_directory is called correctly for test masks
    mock_flow_from_directory.assert_any_call(
        f"{patched_dataset_path}/dataset_patched/masks/{data_type}/test",
        target_size=(256, 256),
        batch_size=16,
        class_mode=None,
        color_mode="grayscale",
        seed=42,
    )

    # Check that flow_from_directory is called correctly for validation images
    mock_flow_from_directory.assert_any_call(
        f"{patched_dataset_path}/dataset_patched/images/val",
        target_size=(256, 256),
        batch_size=16,
        class_mode=None,
        color_mode="grayscale",
        seed=42,
    )

    # Check that flow_from_directory is called correctly for validation masks
    mock_flow_from_directory.assert_any_call(
        f"{patched_dataset_path}/dataset_patched/masks/{data_type}/val",
        target_size=(256, 256),
        batch_size=16,
        class_mode=None,
        color_mode="grayscale",
        seed=42,
    )

    # Check the types of returned generators
    assert isinstance(train_generator, zip)
    assert isinstance(test_generator, zip)
    assert isinstance(val_generator, zip)
