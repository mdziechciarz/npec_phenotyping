import cv2
import numpy as np
import pytest
from src2.instance_segmentation import segment_instances


@pytest.fixture
def example_mask():
    # Create a simple example mask for testing
    mask = np.zeros((100, 100), dtype=np.uint8)
    cv2.circle(mask, (50, 50), 20, 255, -1)
    return mask


def test_segment_instances(example_mask):
    # Call the function with the example mask
    markers = segment_instances(example_mask)

    # Check if the output is of the correct type
    assert isinstance(markers, (np.ndarray, np.generic)) or hasattr(
        markers, "__array__"
    )

    # Check if the output has the same shape as the input mask
    assert markers.shape == example_mask.shape

    # Check if the output contains multiple segments (excluding background)
    assert markers.max() > 1

    # Check if the output contains only integer values
    assert markers.dtype == np.int32
