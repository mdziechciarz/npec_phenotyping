import secrets
api_key = secrets.token_hex(16)
print(api_key)